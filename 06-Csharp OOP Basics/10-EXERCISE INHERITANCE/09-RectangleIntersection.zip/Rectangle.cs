﻿using System;

public class Rectangle
{
    public string Id { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public int TopLeftX { get; set; }
    public int TopLeftY { get; set; }

    public Rectangle(string inputRectangle)
    {
       var args = inputRectangle.Split();
        Id = args[0];
        Width = Math.Abs(int.Parse(args[1]));
        Height = Math.Abs(int.Parse(args[2]));
        TopLeftX = int.Parse(args[3]);
        TopLeftY = int.Parse(args[4]);
       
    }

    public bool IsThereIntersection(Rectangle rectangle)
    {
        return rectangle.TopLeftX + rectangle.Width >= this.TopLeftX &&
                rectangle.TopLeftX <= this.TopLeftX + this.Width &&
                rectangle.TopLeftY >= this.TopLeftY - this.Height &&
                rectangle.TopLeftY - rectangle.Height <= this.TopLeftY;
    }
}